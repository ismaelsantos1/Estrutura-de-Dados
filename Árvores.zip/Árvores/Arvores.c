#include "Arvores.h"
#include <stdio.h>
#include <stdlib.h>

struct No *criarArv(int num){

    struct No *raiz = (struct No*) malloc(sizeof(struct No));

    if(raiz != NULL){
        raiz->num = num;
        raiz->FB = 0;
        raiz->fesq = NULL;
        raiz->fdir = NULL; 
    }
    return raiz;

}


int altura(struct No *arv){
    if(arv == NULL){
        return 0;
    }

    int alturaMax = 0;
    int alturaEsq = altura(arv->fesq);
    int alturaDir = altura(arv->fdir);

    if(alturaDir > alturaEsq){
        
        alturaMax = alturaEsq +1;
    
    } else{
        alturaMax = alturaDir + 1;
    }
    return alturaMax;
}

int fDeBalanceamento(struct No *arv){
    if(arv == NULL){
        return 0;
    }

    int FB = (altura(arv->fesq))- (altura(arv->fdir));
    return FB;
}

struct No *rotDir(struct No *arv){
    struct No *x;
    int minA, maxB;

    x = arv->fesq;

    if(x->FB < 0){
        maxB = x->FB;
    }else{
        maxB = 0;
    }
    arv->FB = arv->FB + 1 - maxB;

    if(arv->FB > 0){
        minA = arv->FB;
    }else{
        minA = 0;
    }
    x->FB = x->FB + 1 + minA;

    arv->fesq = x->fdir;
    x->fdir = arv;

    return x;
}

struct No *rotEsq(struct No *arv){

    struct No *y;
    int minB, maxA;
    y = arv->fdir;

    minB = y->FB < 0 ? y->FB : 0;

    arv->FB = arv->FB +1 - minB;
    
    maxA = arv->FB  > 0 ? arv->FB : 0;

    y-> FB = y->FB +1 + maxA;

    arv->fdir = y->fesq;
    y->fesq = arv;

    if(y->FB <0){

        minB = y->FB;

    } else{
        minB = 0;
    }

    arv->FB = arv->FB +1 - minB;
    return y;

}

struct No *balancear(struct No *arv, int num){

    if(arv == NULL){
        return arv;
    }

    arv->FB = fDeBalanceamento(arv);

    if(arv->FB > 1){
        //Se LL: Desbalanceamento à esq do filho do esq

        if (num < arv->fesq->num){
            return rotDir(arv);
        }

        //Se LR: Desbalanceamento à direita do filho esq
        else if(num>arv->fesq->num){
            arv->fesq = rotEsq(arv->fesq);

            return rotDir(arv);
        }
    }

    if(arv->FB< -1){
        //Caso RR: Desbalanceamento à direita do filho direito

        if(num>arv->fdir->num){
            return rotEsq(arv);
        }

        //caso RL: Desbalanceamento à esq do filho direito
        else if(num < arv->fdir->num){
            arv->fdir = rotDir(arv->fdir);
            return rotEsq(arv);
        }
    }
    return arv;
}

struct No *inserir(struct No *arv, int num){
    if(arv == NULL){
        arv= criarArv(num);
        return arv;
    }
    if(num>arv->num){//caso seja maior do que a raiz, vai pra direita
    
        arv->fdir = inserir(arv->fdir, num);
    }else if(num<arv->num){ //se for menor que a raiz, vai pra esquerda
        arv->fesq = inserir(arv->fesq, num);
    } else{
        return arv;
    }

    arv->FB = fDeBalanceamento(arv);

    return balancear(arv, num);
}


struct No * remover(struct No *arv, int num){

    if(arv == NULL) {
        return NULL;
    
    }else{
        if(arv->FB == num){//procurar o n
            if(arv->fesq == NULL && arv->fdir == NULL){//nós que não tem filho
            free(arv);
            printf("Elemento folha removido: %d \n", num);
            return NULL;
            
            }else{
                if(arv->fesq != NULL && arv->fdir){//remover no c 2 filh
                    struct No *aux = arv->fdir;                                                                                
                    while(aux->fesq != NULL){
                        aux = aux->fesq;
                }
                    arv->FB = aux->FB;
                    aux->FB =num;
                    printf("Elemento trocado: %d \n", num);
                    arv->fdir =remover(arv->fdir, num); 
                    return arv;
                    
                }else{//no que tem 1 filho(fesq ou fdir)

                    struct No *aux;
                    if(arv->fesq != NULL){
                        aux = arv->fesq;
                }else{
                    aux = arv->fdir;
                }
                    free(arv);
                    printf("Elemento com um filho removido: %d", num);
                    return aux;
                }
            }
        
        }else{
            if(num < arv->FB){
                arv->fesq = remover(arv->fesq, num);
            }else{
                arv->fdir = remover(arv->fdir, num);
                return arv;
            }
        }
        return arv;
    }
}
