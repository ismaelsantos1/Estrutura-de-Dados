#include <stdio.h>
#include "Arvores.h"
#include <stdlib.h>

int main() {
  struct No *arv = NULL;

    imprime(arv);

    arv = inserir(arv, 5);
    imprime(arv);

    arv = inserir(arv, 3);
    imprime(arv);

    arv = inserir(arv, 2);
    imprime(arv);

    arv = inserir(arv, 4);
    imprime(arv);

    arv = inserir(arv, 7);
    imprime(arv);

    arv = inserir(arv, 6);
    imprime(arv);

    arv = inserir(arv, 8);
    imprime(arv);

    printf("BUSCAR 6 = %d\n", busca(arv, 6));
    printf("BUSCAR 10 = %d\n", busca(arv, 10));

    arv = remover(arv, 4);
    imprime(arv);

    arv = remover(arv, 5);
    imprime(arv);
    return 0;
}
